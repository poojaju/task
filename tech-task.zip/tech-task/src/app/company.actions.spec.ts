import * as CompanyActions from './company.actions';

describe('Company', () => {
  it('should create an instance', () => {
    expect(new CompanyActions.YCompanys()).toBeTruthy();
  });
});
