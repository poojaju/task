import { Action } from '@ngrx/store';
import {Company } from './company.model'
import {CompanyActions, CompanyActionTypes} from './company.actions'
export const companyFeatureKey = 'company';

export interface State {
companyData:Company[],
error: string
}

export const initialState: State = {
  companyData:[
    {
      message:"induction",
      date:"13.08.2021",
      days:"14d",
      picture:"https://tse3.mm.bing.net/th?id=OIP.0EBu6vZyxeNBmCzAPLi5tgHaHa&pid=Api&P=0&w=153&h=153",
      icon:"http://www.clker.com/cliparts/P/u/5/K/W/c/alert-icon-red-hi.png"
    }],
  error: ''
};

export function reducer(state = initialState, action: CompanyActions): State {
  switch (action.type) {
    case CompanyActionTypes.YCompanys:
      return {
        ...state
      }

    case CompanyActionTypes.YCompanysSuccess:
      return {
        ...state,
        companyData: action.payload.data,
      }

    case CompanyActionTypes.YCompanysFailure:
      return {
        ...state,
        companyData: [],
        error: action.payload.error
      }
    default:
      return state;
  }
}
