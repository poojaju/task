import {
  ActionReducer,
  ActionReducerMap,
  createFeatureSelector,
  createSelector,
  MetaReducer
} from '@ngrx/store';
import { environment } from '../../environments/environment';
import * as fromCompany from '../company.reducer';


export interface State {

  [fromCompany.companyFeatureKey]: fromCompany.State;
}

export const reducers: ActionReducerMap<State,any> = {

  [fromCompany.companyFeatureKey]: fromCompany.reducer,
};


export const metaReducers: MetaReducer<State>[] = !environment.production ? [] : [];