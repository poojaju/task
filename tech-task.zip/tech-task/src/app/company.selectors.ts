import { createFeatureSelector, createSelector } from '@ngrx/store';
import { State } from './company.reducer'

const getCompanyFeatureState = createFeatureSelector<State>('usersState');

export const getCompany = createSelector(
    getCompanyFeatureState,
    (state)=>{
      return  state.companyData
    } 
)

export const getError = createSelector(
    getCompanyFeatureState,
    state => state.error
)
