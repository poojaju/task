import { Injectable } from '@angular/core';
import { Actions, Effect ,ofType} from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { Action } from '@ngrx/store';
import * as companyActions from './company.actions';
import { CompanyService } from './company.service';
import { mergeMap, map, catchError } from 'rxjs/operators';


@Injectable()
export class CompanyEffects {

  constructor(private actions$: Actions,private cs:CompanyService) {}
  @Effect()
  YCompanys$:Observable<Action> = this.actions$.pipe(
    ofType(companyActions.CompanyActionTypes.YCompanys),
    mergeMap(
      action => this.cs.getCompany().pipe(
        map(companyData => (new companyActions.YCompanysSuccess({ data: companyData }))),
        catchError(err => of(new companyActions.YCompanysFailure({ error: err })))
      )
    )
  )
}
