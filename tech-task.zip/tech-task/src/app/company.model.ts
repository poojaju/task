export interface Company {
        message:string,
        date:string,
        days:string,
        picture:string,
        icon:string
    
}

