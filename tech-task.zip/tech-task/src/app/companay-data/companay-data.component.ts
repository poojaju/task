import { Component, OnInit } from '@angular/core';
import { Company } from '../company.model';
import { CompanyService } from '../company.service';
import { Store, select} from '@ngrx/store';
import * as CompanyActions from '../company.actions';
import * as fromCompany from '../company.selectors';
@Component({
  selector: 'app-companay-data',
  templateUrl: './companay-data.component.html',
  styleUrls: ['./companay-data.component.scss']
})
export class CompanayDataComponent implements OnInit {
  errorMessage = '';
  companyData: Company[] = [];
  constructor(private store: Store,private cs:CompanyService) { }

  ngOnInit(){
  this.cs.getCompany().subscribe((response)=>{
    this.companyData = response;
    console.log('response',response)
    });
   this.store.dispatch(new CompanyActions.YCompanys()); // action dispatch
   this.store.pipe(select(fromCompany.getCompany)).subscribe(
     companyData => {
       this.companyData = companyData;
       console.log('data',companyData)
     }
   )
   this.store.pipe(select(fromCompany.getError)).subscribe(
     err =>{
       this.errorMessage = err;
     }
   )
  }

}
