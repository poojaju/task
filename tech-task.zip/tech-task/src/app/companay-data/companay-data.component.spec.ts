import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanayDataComponent } from './companay-data.component';

describe('CompanayDataComponent', () => {
  let component: CompanayDataComponent;
  let fixture: ComponentFixture<CompanayDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompanayDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanayDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
