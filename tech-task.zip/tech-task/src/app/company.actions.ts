import { Action } from '@ngrx/store';
import { Company } from './company.model';

export enum CompanyActionTypes {
  YCompanys = '[Company] Y Companys',
  YCompanysSuccess = '[Company] Y Companys Success',
  YCompanysFailure = '[Company] Y Companys Failure',
}

export class YCompanys implements Action {
  readonly type = CompanyActionTypes.YCompanys;
}

export class YCompanysSuccess implements Action {
  readonly type = CompanyActionTypes.YCompanysSuccess;
  constructor(public payload: { data: Company[]}) { }
}

export class YCompanysFailure implements Action {
  readonly type = CompanyActionTypes.YCompanysFailure;
  constructor(public payload: { error: string }) { }
}

export type CompanyActions = YCompanys | YCompanysSuccess | YCompanysFailure;

